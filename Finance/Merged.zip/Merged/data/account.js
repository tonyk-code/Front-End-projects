export const accounts = [
  { 
    id: "acc001", 
    email: "yesehakkebere@gmail.com", 
    password: "password123" 
  },
  { 
    id: "acc002", 
    email: "jane.smith@example.com", 
    password: "qwerty456" 
  },
  { 
    id: "acc003", 
    email: "michael.lee@example.com", 
    password: "helloWorld1" 
  },
  { 
    id: "acc004", 
    email: "sarah.connor@example.com", 
    password: "skynet2029" 
  },
  { 
    id: "acc005", 
    email: "emma.watson@example.com", 
    password: "magic123" 
  },
  { 
    id: "acc006", 
    email: "peter.parker@example.com", 
    password: "sp1derm@n" 
  },
  { 
    id: "acc007", 
    email: "tony.stark@example.com", 
    password: "ironman3000" 
  },
  { 
    id: "acc008", 
    email: "bruce.wayne@example.com", 
    password: "batm@n" 
  },
  { 
    id: "acc009", 
    email: "clark.kent@example.com", 
    password: "superman007" 
  },
  { 
    id: "acc010", 
    email: "diana.prince@example.com", 
    password: "wonder123" 
  },
  { 
    id: "acc011", 
    email: "steve.rogers@example.com", 
    password: "captain1945" 
  },
  { 
    id: "acc012", 
    email: "natasha.romanoff@example.com", 
    password: "widow$ecure" 
  },
  { 
    id: "acc013", 
    email: "bruce.banner@example.com", 
    password: "hulkSmash!" 
  },
  { 
    id: "acc014", 
    email: "thor.odinson@example.com", 
    password: "mjolnir2025" 
  },
  { 
    id: "acc015", 
    email: "loki.laufeyson@example.com", 
    password: "tr1ckst3r" 
  },
  { 
    id: "acc016", 
    email: "wanda.maximoff@example.com", 
    password: "scarlet!witch" 
  },
  { 
    id: "acc017", 
    email: "stephen.strange@example.com", 
    password: "multiverse88" 
  },
  { 
    id: "acc018", 
    email: "scott.lang@example.com", 
    password: "antmanTiny" 
  },
  { 
    id: "acc019", 
    email: "carol.danvers@example.com", 
    password: "captMarvel9" 
  },
  { 
    id: "acc020", 
    email: "nick.fury@example.com", 
    password: "shieldAccess!" 
  }
];
